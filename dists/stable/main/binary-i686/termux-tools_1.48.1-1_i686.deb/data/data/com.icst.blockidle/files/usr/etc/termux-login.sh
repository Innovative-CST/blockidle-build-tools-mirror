##
## This script is sourced by /data/data/com.icst.blockidle/files/usr/bin/login before executing shell.
##

#ifndef _CHECK_CHECK_STDINT_H
#define _CHECK_CHECK_STDINT_H 1
#ifndef _GENERATED_STDINT_H
#define _GENERATED_STDINT_H "check 0.15.2"
/* generated using gnu compiler Android (13989888, +pgo, +bolt, +lto, +mlgo, based on r563880c) clang version 21.0.0 (https://android.googlesource.com/toolchain/llvm-project 5e96669f06077099aa41290cdb4c5e6fa0f59349) */
#define _STDINT_HAVE_STDINT_H 1
#include <stdint.h>
#endif
#endif

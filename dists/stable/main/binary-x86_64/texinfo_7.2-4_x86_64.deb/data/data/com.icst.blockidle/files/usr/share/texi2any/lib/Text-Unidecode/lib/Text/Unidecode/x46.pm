#  Time-stamp: "2014-07-22 05:15:15 MDT sburke@cpan.org"
$Text::Unidecode::Char[ 0x46 ] = Text::Unidecode::make_placeholder_map();
1;
